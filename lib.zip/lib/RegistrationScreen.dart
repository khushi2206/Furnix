import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:furnix/LoginScreen.dart';
import 'package:furnix/function.dart';
import 'package:google_sign_in/google_sign_in.dart';

class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  TextEditingController nameT = TextEditingController();
  TextEditingController emailT = TextEditingController();
  TextEditingController passwordT = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  bool isGoogleLoading = false;
  File? selectedFile;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade50,
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Create Account",
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.blue.shade700),
                ),
                SizedBox(height: 20),
                GestureDetector(
                  onTap: () async {
                    var image = await getImage(1);
                    if (image != null) {
                      setState(() => selectedFile = File(image.path));
                    }
                  },
                  child: CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.blue.shade200,
                    backgroundImage: selectedFile != null ? FileImage(selectedFile!) : null,
                    child: selectedFile == null ? Icon(Icons.camera_alt, size: 30, color: Colors.white) : null,
                  ),
                ),
                SizedBox(height: 20),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _buildTextField(nameT, "Full Name", Icons.person),
                      _buildTextField(emailT, "Email", Icons.email, isEmail: true),
                      _buildTextField(passwordT, "Password", Icons.lock, isPassword: true),
                      SizedBox(height: 20),
                      isLoading
                          ? CircularProgressIndicator()
                          : _buildButton("Sign Up", _signUp),
                      SizedBox(height: 10),
                      Text("Or", style: TextStyle(color: Colors.blue.shade700)),
                      SizedBox(height: 10),
                      isGoogleLoading
                          ? CircularProgressIndicator()
                          : _buildButton("Sign Up with Google", _signInWithGoogle, isGoogle: true),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                TextButton(
                  onPressed: () => Navigator.pushReplacementNamed(context, "/login"),
                  child: Text("Already have an account? Login", style: TextStyle(color: Colors.blue.shade700)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {bool isPassword = false, bool isEmail = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword,
        keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.blue.shade700),
          hintText: hint,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) return "Please enter $hint";
          if (isEmail && !RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$').hasMatch(value)) {
            return "Enter a valid email";
          }
          if (isPassword && value.length < 6) {
            return "Password must be at least 6 characters";
          }
          return null;
        },
      ),
    );
  }

  Widget _buildButton(String text, VoidCallback onPressed, {bool isGoogle = false}) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: isGoogle ? Colors.white : Colors.blue.shade700,
        foregroundColor: isGoogle ? Colors.black : Colors.white,
        minimumSize: Size(double.infinity, 50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        side: isGoogle ? BorderSide(color: Colors.blue.shade700) : BorderSide.none,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (isGoogle) Icon(Icons.g_mobiledata, color: Colors.blue.shade700),
          if (isGoogle) SizedBox(width: 8),
          Text(text, style: TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
  Future<void> _checkEmailAndProceed(String email, Function onSuccess) async {
    try {
      // Check if email exists in Firebase Authentication
      final existingUserAuth = await _auth.fetchSignInMethodsForEmail(email);

      if (existingUserAuth.isNotEmpty) {
        // User exists in Firebase Authentication
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("User is already registered in Authentication. Please log in.")),
        );
        return;
      }

      // Check if the email exists in Firestore database
      final existingUserFirestore = await _firestore.collection("users").where("email", isEqualTo: email).get();

      if (existingUserFirestore.docs.isNotEmpty) {
        // Email already exists in Firestore
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("User is already registered. Please log in.")),
        );
      }
    } catch (e) {
      // Handle any errors
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error checking email: ${e.toString()}")),
      );
    }
  }



  Future<void> _signUp() async {
    if (_formKey.currentState!.validate()) {
      setState(() => isLoading = true);
      try {
        await _checkEmailAndProceed(emailT.text.trim(), () async {
          // Proceed with the sign-up process if email is not already registered
          UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
            email: emailT.text.trim(),
            password: passwordT.text.trim(),
          );

          String uid = userCredential.user!.uid;
          String imageUrl = "";

          if (selectedFile != null) {
            // Compress image if needed here before uploading
            var ref = FirebaseStorage.instance.ref().child('user_images/$uid.jpg');
            await ref.putFile(selectedFile!);
            imageUrl = await ref.getDownloadURL();
          }

          await _firestore.collection("users").doc(uid).set({
            "uid": uid,
            "name": nameT.text.trim(),
            "email": emailT.text.trim(),
            "password": passwordT.text.trim(),
            "image": imageUrl,
          });

          // Only navigate to the login screen if sign-up is successful
          Navigator.pushReplacementNamed(context, "/login");
        });
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Sign Up Failed: ${e.toString()}")));
      } finally {
        setState(() => isLoading = false);
      }
    }
  }


  Future<void> _signInWithGoogle() async {
    setState(() => isGoogleLoading = true);
    try {
      await _googleSignIn.signOut();

      // Start the Google Sign-In process
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        setState(() => isGoogleLoading = false);
        return; // User canceled the login
      }

      // Obtain the Google authentication tokens
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

      // Use the credentials to sign in with Firebase
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Authenticate the user with Firebase
      UserCredential userCredential = await _auth.signInWithCredential(credential);
      String uid = userCredential.user!.uid;

      // Check if the user's email is already registered
      await _checkEmailAndProceed(userCredential.user!.email!, () async {
        // Proceed with storing user details in Firestore if email is not already registered
        await _firestore.collection("users").doc(uid).set({
          "uid": uid,
          "name": userCredential.user!.displayName ?? "",
          "email": userCredential.user!.email ?? "",
          "image": userCredential.user!.photoURL ?? "", // Store the profile image URL from Google
        }, SetOptions(merge: true));

        // Navigate to the login screen after successful sign-in
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginScreen()), // Replace LoginScreen() with your actual login widget
        );

      });
    } catch (e) {
      // Handle any errors during Google sign-in
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Google Sign-In Failed: ${e.toString()}")));
    } finally {
      setState(() => isGoogleLoading = false);
    }
  }







}
